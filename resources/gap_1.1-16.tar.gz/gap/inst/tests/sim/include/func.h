#ifndef FUNC_H
#define FUNC_H

typedef enum boolean {false, true} boolean;

#endif
