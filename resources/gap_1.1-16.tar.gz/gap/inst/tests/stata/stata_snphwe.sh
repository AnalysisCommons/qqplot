gcc -shared -DSYSTEM=OPUNIX -fPIC stplugin.c stata_snphwe.c -o stata_snphwe.plugin

