gcc  -std=gnu99 -shared -o snphwe.so snphwe.c -fPIC
